<?php
include "CardDetailsDAO.php";
if(isset($_GET['first_name']) && isset($_GET['last_name']) && isset($_GET['card_number']) && isset($_GET['exp_month']) && isset($_GET['exp_year']) && isset($_GET['cvv']) && isset($_GET['card_type'])){
	$first_name = $_GET['first_name'];
	$last_name = $_GET['last_name'];
	$card_number = $_GET['card_number'];
	$exp_month = $_GET['exp_month'];
	$exp_year = $_GET['exp_year'];
	$cvv = $_GET['cvv'];
	$card_type = $_GET['card_type'];
	if($first_name != '' && $last_name != '' && $card_type != '' && !is_nan($card_number) && !is_nan($exp_month) && !is_nan($exp_year) && !is_nan($cvv)){
		$dao = new CardDetailsDAO();
		$data = $dao->insertData($first_name, $last_name, $card_number, $exp_month, $exp_year, $cvv, $card_type);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
	}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>