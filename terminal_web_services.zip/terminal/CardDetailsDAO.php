<?php
include "db_connect.php";
class CardDetailsDAO {
		
		private $connection;
		public function __construct(){
			$obj_con=   new Connection("localhost","terminal","root","");	
			$this->connection = $obj_con->getConnection();
			$this->connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		
		public function insertData($firstname, $lastname, $cardnumber, $expmonth, $expyear, $cvv, $card_type){
			$stm = $this->connection->exec("INSERT INTO card_details VALUES(NULL, '$firstname', '$lastname', '$cardnumber', '$expmonth', '$expyear', '$cvv', '$card_type')");
		}
		
		
		
		// AND `Time`='$time' AND `Zone`='$zone' AND `GuardId`='$guardid' AND `CheckIn`='$checkin'
}
?>