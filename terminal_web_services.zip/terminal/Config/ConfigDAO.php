<?php
include "../db_connect.php";
class ConfigDAO {
		
		private $connection;
		public function __construct(){
			$obj_con=   new Connection("localhost","terminal","root","");	
			$this->connection = $obj_con->getConnection();
			$this->connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		
		public function insertConfig($language, $currency, $taxrate, $enablepin, $paypal_email){
			$stm = $this->connection->exec("INSERT INTO config VALUES(NULL, '$language', '$currency', '$taxrate', '$enablepin', '$paypal_email')");
		}
		
		public function updateConfig($id, $language, $currency, $taxrate, $enablepin, $paypal_email){
			$stm = $this->connection->exec("UPDATE config SET `language`='$language' , `currency`='$currency' , `taxRate`='$taxrate' , `enablePin`='$enablepin', `paypal_email`='$paypal_email' WHERE id=$id");
		}
		
		public function deleteConfig($id){
			$stm = $this->connection->exec("DELETE FROM config WHERE id=$id");	
		}
		
		public function getConfigById($id){
			$stm = $this->connection->query("SELECT * FROM config WHERE id=$id");
			$result = $stm->fetch(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getConfigs(){
			$stm = $this->connection->query("SELECT * FROM data ORDER BY id ASC");// AND `CheckIn`='$checkin'
			$results = array();
			while ($result = $stm->fetch(PDO::FETCH_ASSOC)){
				$results[] = $result;
			}
			return $results;
		}
		
		// AND `Time`='$time' AND `Zone`='$zone' AND `GuardId`='$guardid' AND `CheckIn`='$checkin'
}
?>