<?php
include "ConfigDAO.php";
if(isset($_GET['language']) && isset($_GET['currency']) && isset($_GET['taxRate']) && isset($_GET['enablePin'])){
	$language = $_GET['language'];
	$currency = $_GET['currency'];
	$taxRate = $_GET['taxRate'];
	$enablePin = $_GET['enablePin'];
	
	if($language != '' && $currency != '' && is_double($taxRate) && !is_nan($enablePin)){
		$dao = new ConfigDAO();]
		$data = $dao->insertConfig($language, $currency, $taxRate, $enablePin);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
