<?php
include "ConfigDAO.php";
if(isset($_GET['id']) && isset($_GET['language']) && isset($_GET['currency']) && isset($_GET['taxRate']) && isset($_GET['enablePin']) && isset($_GET['paypal_email']) && isset($_GET['popup'])){
	$language = $_GET['language'];
	$currency = $_GET['currency'];
	$taxRate = $_GET['taxRate'];
	$enablePin = $_GET['enablePin'];
	$id = $_GET['id'];
	$paypal_email = $_GET['paypal_email'];
	$popup = $_GET['popup'];
	
	if(!is_nan($enablePin) && !is_nan($id)){
		$dao = new ConfigDAO();
		$data = $dao->updateConfig($id, $language, $currency, $taxRate, $enablePin, $paypal_email, $popup);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
