<?php
include "ConfigDAO.php";
if(isset($_GET['id']) && isset($_GET['language']) && isset($_GET['currency']) && isset($_GET['taxRate']) && isset($_GET['enablePin'])){
	$language = $_GET['language'];
	$currency = $_GET['currency'];
	$taxRate = $_GET['taxRate'];
	$enablePin = $_GET['enablePin'];
	$id = $_GET['id'];
	
	if($language != '' && $currency != '' && is_double($taxRate) && !is_nan($enablePin) && !is_nan($id)){
		$dao = new ConfigDAO();]
		$data = $dao->insertConfig($id, $language, $currency, $taxRate, $enablePin);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
