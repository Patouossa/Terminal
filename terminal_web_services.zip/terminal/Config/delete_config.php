<?php
include "ConfigDAO.php";
if(isset($_GET['id'])){
	$id = $_GET['id'];
	
	if(!is_nan($id)){
		$dao = new ConfigDAO();
		$data = $dao->deleteConfig($id);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
