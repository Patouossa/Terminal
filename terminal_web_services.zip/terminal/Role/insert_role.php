<?php
include "RoleDAO.php";
if(isset($_GET['name'])){
	$name = $_GET['name'];
	
	if($name != ''){
		$dao = new RoleDAO();
		$data = $dao->insertRole($name);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
