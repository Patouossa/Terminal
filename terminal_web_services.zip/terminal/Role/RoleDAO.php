<?php
include "../db_connect.php";
class RoleDAO {
		
		private $connection;
		public function __construct(){
			$obj_con=   new Connection("localhost","terminal","root","");	
			$this->connection = $obj_con->getConnection();
			$this->connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		
		public function insertRole($name){
			$stm = $this->connection->exec("INSERT INTO role VALUES(NULL, '$name')");
		}
		
		public function updateRole($id, $name){
			$stm = $this->connection->exec("UPDATE Role SET `name`='$name' WHERE id=$id");
		}
		
		public function deleteRole($id){
			$stm = $this->connection->exec("DELETE FROM role WHERE id=$id");	
		}
		
		public function getRoleById($id){
			$stm = $this->connection->query("SELECT * FROM role WHERE id=$id");
			$result = $stm->fetch(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRoles(){
			$stm = $this->connection->query("SELECT * FROM role");// AND `CheckIn`='$checkin'
			
			$results = array();
			while ($result = $stm->fetch(PDO::FETCH_ASSOC)){
				$results[] = $result;
			}
			return $results;
		}
		
		// AND `Time`='$time' AND `Zone`='$zone' AND `GuardId`='$guardid' AND `CheckIn`='$checkin'
}
?>