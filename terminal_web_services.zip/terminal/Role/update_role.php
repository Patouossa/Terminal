<?php
include "RoleDAO.php";
if(isset($_GET['id']) && isset($_GET['name'])){
	$id = $_GET['id'];
	$name = $_GET['name'];
	
	if(!is_nan($id) && $name != ''){
		$dao = new RoleDAO();
		$data = $dao->updateRole($id, $name);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
