<?php
include "../db_connect.php";
class PrivilegeDAO {
		
		private $connection;
		public function __construct(){
			$obj_con=   new Connection("localhost","terminal","root","");	
			$this->connection = $obj_con->getConnection();
			$this->connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		
		public function insertPrivilege($idRole, $idRight, $description){
			$stm = $this->connection->exec("INSERT INTO privilege VALUES(NULL, '$idRole', '$idRight', '$description')");
		}
		
		public function updatePrivilege($id, $time, $zone, $guardid, $checkin){
			$stm = $this->connection->exec("UPDATE privilege SET `idRole`='$idRole' , `idRight`='$idRight' , `description`='$description' WHERE id=$id");
		}
		
		public function deletePrivilege($id){
			$stm = $this->connection->exec("DELETE FROM privilege WHERE id=$id");	
		}
		
		public function getPrivilegeById($id){
			$stm = $this->connection->query("SELECT * FROM privilege WHERE id=$id");
			$result = $stm->fetch(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getPrivileges(){
			$stm = $this->connection->query("SELECT * FROM privilege ORDER BY id ASC");// AND `CheckIn`='$checkin'
			$results = array();
			while ($result = $stm->fetch(PDO::FETCH_ASSOC)){
				$results[] = $result;
			}
			return $results;
		}
		
		// AND `Time`='$time' AND `Zone`='$zone' AND `GuardId`='$guardid' AND `CheckIn`='$checkin'
}
?>