<?php
include "PrivilegeDAO.php";
if(isset($_GET['idRole']) && isset($_GET['idRight']) && isset($_GET['description'])){
	$idRole = $_GET['idRole'];
	$idRight = $_GET['idRight'];
	$description = $_GET['description'];
	
	if($description != '' && !is_nan($idRight) && !is_nan($idRole)){
		$dao = new PrivilegeDAO();
		$data = $dao->insertPrivilege($idRole, $idRight, $description);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
