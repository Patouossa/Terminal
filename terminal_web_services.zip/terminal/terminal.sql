-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le: Ven 23 Septembre 2016 à 16:03
-- Version du serveur: 5.5.27
-- Version de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `terminal`
--
CREATE DATABASE `terminal` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `terminal`;

-- --------------------------------------------------------

--
-- Structure de la table `card_details`
--

CREATE TABLE IF NOT EXISTS `card_details` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `CardNumber` int(11) NOT NULL,
  `ExpireryMonth` int(11) NOT NULL,
  `ExpireryYear` int(11) NOT NULL,
  `CVV` int(11) NOT NULL,
  `CardType` varchar(15) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `card_details`
--

INSERT INTO `card_details` (`Id`, `FirstName`, `LastName`, `CardNumber`, `ExpireryMonth`, `ExpireryYear`, `CVV`, `CardType`) VALUES
(1, 'hjjk', 'ttty', 2147483647, 8, 2019, 530, 'Visa'),
(2, 'Patouossa', 'Ibrahim', 2147483647, 8, 2019, 538, 'Visa'),
(3, 'Patouossa', 'Ibrahim', 2147483647, 8, 2019, 530, 'Visa');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
