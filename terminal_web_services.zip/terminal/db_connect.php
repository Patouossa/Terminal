<?php
class Connection {
	private $connection;
	public function __construct($host, $db, $user, $pass)  {
		try{
			$this->connection = new PDO("mysql:host=".$host.";dbname=".$db, $user,
	$pass);
		} catch (PDOException $e) {
		echo $e->getMessage();
		}
	}
	
	public function getConnection(){
		return $this->connection;	
	}
}
?>
