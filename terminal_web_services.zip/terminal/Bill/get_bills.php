<?php
include "BillDAO.php";
$dao = new BillDAO();
$data = $dao->getBills();
if($data == false){
	$error["status"] = "Error";
	$error["error"] = "No data match";
	echo json_encode($error);
}
else{
	$success["status"] = "OK";
	$success["data"] = $data;
	echo json_encode($success);
}
			
?>