<?php
include "BillDAO.php";
if(isset($_GET['amount']) && isset($_GET['note']) && isset($_GET['status']) && isset($_GET['id'])){
	$amount = $_GET['amount'];
	$note = $_GET['note'];
	$status = $_GET['status'];
	$id = $_GET['id'];
	
	if($note != '' && $status != '' && !is_nan($id) && is_double($amount)){
		$dao = new BillDAO();]
		$data = $dao->insertBill($id, $amount, $note, $status);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
