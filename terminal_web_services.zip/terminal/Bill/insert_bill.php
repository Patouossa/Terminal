<?php
include "BillDAO.php";
if(isset($_GET['amount']) && isset($_GET['note']) && isset($_GET['status']) && isset($_GET['insertUser'])){
	$amount = $_GET['amount'];
	$note = $_GET['note'];
	$status = $_GET['status'];
	$insertUser = $_GET['insertUser'];
	
	if($note != '' && $status != '' && !is_nan($insertUser) && is_double($amount)){
		$dao = new BillDAO();
		$data = $dao->insertBill($amount, $note, $status, $insertUser);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
