<?php
include "../db_connect.php";
class UserDAO {
		
		private $connection;
		public function __construct(){
			$obj_con=   new Connection("localhost","terminal","root","");	
			$this->connection = $obj_con->getConnection();
			$this->connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		
		public function insertUser($username, $password, $firstname, $lastname, $sex, $address, $isWaiter, $idRole, $insertUser, $editUser){
			$stm = $this->connection->exec("INSERT INTO user VALUES(NULL, '$username', '".md5($password)."', '$firstname', '$lastname', '$sex', '$address', '$isWaiter', '$idRole', '$insertUser', '$editUser', CURDATE(), CURDATE())");
		}
		
		public function updateUser($id, $username, $password, $firstname, $lastname, $sex, $address, $isWaiter, $idRole, $editUser){
			$stm = $this->connection->exec("UPDATE user SET `username`='$username' , `password`='".md5($password)."' , `firstname`='$firstname' , `lastname`='$lastname', `sex`='$sex', `address`='$address', `isWaiter`='$isWaiter', `idRole`='$idRole', `editUser`='$editUser', `editDate`=CURDATE() WHERE id=$id");
		}
		
		public function deleteUser($id){
			$stm = $this->connection->exec("DELETE FROM user WHERE id=$id");	
		}
		
		public function getUserById($id){
			$stm = $this->connection->query("SELECT * FROM user WHERE id=$id");
			$result = $stm->fetch(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function loginUser($username, $password){
			$stm = $this->connection->query("SELECT * FROM user WHERE `username`='$username' AND `Password`='".md5($password)."'");
			$result = $stm->fetch(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getUsers(){
			$stm = $this->connection->query("SELECT * FROM user ORDER BY id ASC");// AND `CheckIn`='$checkin'
			
			$results = array();
			while ($result = $stm->fetch(PDO::FETCH_ASSOC)){
				$results[] = $result;
			}
			return $results;
		}
		
		// AND `Time`='$time' AND `Zone`='$zone' AND `GuardId`='$guardid' AND `CheckIn`='$checkin'
}
?>