<?php
include "UserDAO.php";
if(isset($_GET['username']) && isset($_GET['password']) && isset($_GET['firstname']) && isset($_GET['lastname']) && isset($_GET['sex']) && isset($_GET['address']) && isset($_GET['isWaiter']) && isset($_GET['idRole']) && isset($_GET['insertUser']) && isset($_GET['editUser'])){
	$username = $_GET['username'];
	$password = $_GET['password'];
	$firstname = $_GET['firstname'];
	$lastname = $_GET['lastname'];
	$sex = $_GET['sex'];
	$address = $_GET['address'];
	$isWaiter = $_GET['isWaiter'];
	$idRole = $_GET['idRole'];
	$insertUser = $_GET['insertUser'];
	$editUser = $_GET['editUser'];
	
	if($username != '' && $password != '' && $firstname != '' && $lastname != '' && $sex != '' && $address != '' && !is_nan($isWaiter) && !is_nan($idRole) && !is_nan($insertUser) && !is_nan($editUser)){
		$dao = new UserDAO();]
		$data = $dao->insertUser($username, $password, $firstname, $lastname, $sex, $address, $isWaiter, $idRole, $insertUser, $editUser);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
