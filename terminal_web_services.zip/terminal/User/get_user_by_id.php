<?php
include "UserDAO.php";
if(isset($_GET['id'])){
	$id = $_GET['id'];
	
	if(!is_nan($id)){
		$dao = new UserDAO();
		$data = $dao->getUserById($id);
		if($data == false){
			$error["status"] = "Error";
			$error["error"] = "No data match";
			echo json_encode($error);
		}
		else{
			$success["status"] = "OK";
			$success["data"] = $data;
			echo json_encode($success);
			//print_r($data);
		}
	}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
