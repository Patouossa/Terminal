<?php
include "UserDAO.php";
if(isset($_GET['id']) && isset($_GET['username']) && isset($_GET['password']) && isset($_GET['firstname']) && isset($_GET['lastname']) && isset($_GET['sex']) && isset($_GET['address']) && isset($_GET['isWaiter']) && isset($_GET['idRole']) && isset($_GET['editUser'])){
	$username = $_GET['username'];
	$password = $_GET['password'];
	$firstname = $_GET['firstname'];
	$lastname = $_GET['lastname'];
	$sex = $_GET['sex'];
	$address = $_GET['address'];
	$isWaiter = $_GET['isWaiter'];
	$idRole = $_GET['idRole'];
	$editUser = $_GET['editUser'];
	$id = $_GET['id'];
	
	if($username != '' && $password != '' && $firstname != '' && $lastname != '' && $sex != '' && $address != '' && !is_nan($isWaiter) && !is_nan($idRole) && !is_nan($editUser) && !is_nan($id)){
		$dao = new UserDAO();]
		$data = $dao->insertUser($id, $username, $password, $firstname, $lastname, $sex, $address, $isWaiter, $idRole, $editUser);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
