<?php
include "RightDAO.php";
if(isset($_GET['id']) && isset($_GET['code']) && isset($_GET['description'])){
	$code = $_GET['code'];
	$description = $_GET['description'];
	$id = $_GET['id'];
	
	if($name != '' && $description != '' && !is_nan($id)){
		$dao = new RightDAO();
		$data = $dao->updateRight($id, $code, $description);
		$success["status"] = "OK";
		$success["data"] = null;
		echo json_encode($success);
		}
	else{
		$error["status"] = "Error";
		$error["error"] = "Data types mismatch";
		echo json_encode($error);
	}
}
else{
	$error["status"] = "Error";
	$error["error"] = "Missing entries parameters.";
	echo json_encode($error);
}
?>
