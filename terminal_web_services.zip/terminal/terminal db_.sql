-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le: Jeu 06 Octobre 2016 à 17:49
-- Version du serveur: 5.5.27
-- Version de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `terminal`
--
CREATE DATABASE `terminal` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `terminal`;

-- --------------------------------------------------------

--
-- Structure de la table `bill`
--

CREATE TABLE IF NOT EXISTS `bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `note` text NOT NULL,
  `status` text NOT NULL,
  `insertUser` int(11) NOT NULL,
  `insertDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `bill`
--

INSERT INTO `bill` (`id`, `amount`, `note`, `status`, `insertUser`, `insertDate`) VALUES
(1, 10, 'Yo', 'Yo', 1, '2016-09-28 00:00:00'),
(2, 1, '{\n    "response": {\n        "state": "approved",\n        "id": "PAY-2VV256640X003623VK7VZD4I",\n        "create_time": "2016-09-28T09:48:33Z",\n        "intent": "sale"\n    },\n    "client": {\n        "platform": "Android",\n        "paypal_sdk_version": "2.14.6",\n        "product_name": "PayPal-Android-SDK",\n        "environment": "sandbox"\n    },\n    "response_type": "payment"\n}', 'Payment successfully completed', 2, '2016-09-28 00:00:00'),
(3, 2, '{\n    "response": {\n        "state": "approved",\n        "id": "PAY-17A65081C5605124WK7VZY3I",\n        "create_time": "2016-09-28T10:33:17Z",\n        "intent": "sale"\n    },\n    "client": {\n        "platform": "Android",\n        "paypal_sdk_version": "2.14.6",\n        "product_name": "PayPal-Android-SDK",\n        "environment": "sandbox"\n    },\n    "response_type": "payment"\n}', 'Payment successfully completed', 2, '2016-09-28 00:00:00'),
(4, 10, '{\n    "response": {\n        "state": "approved",\n        "id": "PAY-2BX82807XY8970646K7VZ37I",\n        "create_time": "2016-09-28T10:39:57Z",\n        "intent": "sale"\n    },\n    "client": {\n        "platform": "Android",\n        "paypal_sdk_version": "2.14.6",\n        "product_name": "PayPal-Android-SDK",\n        "environment": "sandbox"\n    },\n    "response_type": "payment"\n}', 'Payment successfully completed', 2, '2016-09-28 00:00:00'),
(5, 10, '{\n    "response": {\n        "state": "approved",\n        "id": "PAY-9N853009W4518802JK7VZ43Q",\n        "create_time": "2016-09-28T10:41:50Z",\n        "intent": "sale"\n    },\n    "client": {\n        "platform": "Android",\n        "paypal_sdk_version": "2.14.6",\n        "product_name": "PayPal-Android-SDK",\n        "environment": "sandbox"\n    },\n    "response_type": "payment"\n}', 'Payment successfully completed', 2, '2016-09-28 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `card_details`
--

CREATE TABLE IF NOT EXISTS `card_details` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `CardNumber` int(11) NOT NULL,
  `ExpireryMonth` int(11) NOT NULL,
  `ExpireryYear` int(11) NOT NULL,
  `CVV` int(11) NOT NULL,
  `CardType` varchar(15) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `card_details`
--

INSERT INTO `card_details` (`Id`, `FirstName`, `LastName`, `CardNumber`, `ExpireryMonth`, `ExpireryYear`, `CVV`, `CardType`) VALUES
(1, 'hjjk', 'ttty', 2147483647, 8, 2019, 530, 'Visa'),
(2, 'Patouossa', 'Ibrahim', 2147483647, 8, 2019, 538, 'Visa'),
(3, 'Patouossa', 'Ibrahim', 2147483647, 8, 2019, 530, 'Visa'),
(4, 'ftggh', 'fgyyu', 2147483647, 8, 2019, 530, 'Visa'),
(5, 'ffgg', 'ffgg', 2147483647, 8, 2019, 530, 'Visa');

-- --------------------------------------------------------

--
-- Structure de la table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(10) NOT NULL,
  `currency` varchar(20) NOT NULL,
  `taxRate` double NOT NULL,
  `enablePin` int(11) NOT NULL,
  `paypal_email` varchar(50) NOT NULL,
  `popup` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `config`
--

INSERT INTO `config` (`id`, `language`, `currency`, `taxRate`, `enablePin`, `paypal_email`, `popup`) VALUES
(1, 'English', 'USD', 18, 0, 'itkamer@gmail.com', 0);

-- --------------------------------------------------------

--
-- Structure de la table `privilege`
--

CREATE TABLE IF NOT EXISTS `privilege` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRole` int(11) NOT NULL,
  `idRight` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `right`
--

CREATE TABLE IF NOT EXISTS `right` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'User'),
(2, 'Admin'),
(3, 'Super Admin');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `sex` varchar(7) NOT NULL,
  `address` varchar(25) NOT NULL,
  `isWaiter` int(11) NOT NULL,
  `idRole` int(11) NOT NULL,
  `insertUser` int(11) NOT NULL,
  `editUser` int(11) NOT NULL,
  `insertDate` date NOT NULL,
  `editDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `firstname`, `lastname`, `sex`, `address`, `isWaiter`, `idRole`, `insertUser`, `editUser`, `insertDate`, `editDate`) VALUES
(1, 'Henry24', '202cb962ac59075b964b07152d234b70', '', '', '', '', 0, 1, 0, 0, '2016-09-24', '2016-09-26'),
(2, 'Ibrahim', '202cb962ac59075b964b07152d234b70', '', '', '', '', 0, 1, 0, 0, '2016-09-24', '2016-09-24'),
(3, 'Dr Stanley', '202cb962ac59075b964b07152d234b70', '', '', '', '', 0, 1, 0, 0, '2016-09-24', '2016-09-24'),
(7, 'Landmark', '202cb962ac59075b964b07152d234b70', '', '', '', '', 0, 1, 1, 1, '2016-09-26', '2016-09-26'),
(9, 'Louiza', '202cb962ac59075b964b07152d234b70', '', '', '', '', 0, 1, 1, 1, '2016-09-26', '2016-09-26'),
(10, 'Oben', '202cb962ac59075b964b07152d234b70', '', '', '', '', 0, 1, 1, 1, '2016-09-26', '2016-09-26');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
